/*     */ package me.Eagler;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Main
/*     */   extends JFrame
/*     */   implements ActionListener
/*     */ {
/*     */   public JTextField path;
/*     */   public JButton button;
/*     */   public Path copieq;
/*     */   public Path copiejson;
/*     */   public Path qf;
/*     */   public Path jsonf;
/*     */   public String user;
/*     */   
/*     */   public Main() {
/*  31 */     setLayout((LayoutManager)null);
/*     */     
/*  33 */     this.copieq = Paths.get("Quiet\\Quiet.jar", new String[0]);
/*  34 */     this.copiejson = Paths.get("Quiet\\Quiet.json", new String[0]);
/*     */     
/*  36 */     this.user = System.getProperty("user.name");
/*     */     
/*  38 */     this.path = new JTextField(5);
/*     */     
/*  40 */     this.path.setBounds(10, 10, 370, 30);
/*     */     
/*  42 */     this.path.setText(String.valueOf(System.getProperty("user.home")) + "\\AppData\\Roaming\\.minecraft\\versions");
/*     */     
/*  44 */     this.button = new JButton("Install");
/*     */     
/*  46 */     this.button.setBounds(50, 50, 100, 30);
/*     */     
/*  48 */     this.button.setLocation(150, 50);
/*     */     
/*  50 */     this.button.addActionListener(this);
/*     */     
/*  52 */     setTitle("Quiet Installer");
/*  53 */     setDefaultCloseOperation(3);
/*  54 */     setSize(400, 125);
/*  55 */     setResizable(false);
/*  56 */     setLocationRelativeTo((Component)null);
/*     */     
/*  58 */     add(this.path);
/*  59 */     add(this.button);
/*     */     
/*  61 */     setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/*  74 */     if (e.getSource() == this.button)
/*     */       
/*     */       try {
/*     */         
/*  78 */         File folder = new File(String.valueOf(this.path.getText()) + "\\Quiet");
/*     */         
/*  80 */         if (!folder.exists())
/*     */         {
/*  82 */           folder.mkdirs();
/*     */         }
/*     */ 
/*     */         
/*  86 */         File quiet = new File(String.valueOf(this.path.getText()) + "\\Quiet\\Quiet.jar");
/*  87 */         File json = new File(String.valueOf(this.path.getText()) + "\\Quiet\\Quiet.json");
/*     */         
/*  89 */         if (quiet.exists())
/*     */         {
/*  91 */           quiet.delete();
/*     */         }
/*     */ 
/*     */         
/*  95 */         if (json.exists())
/*     */         {
/*  97 */           json.delete();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 103 */         Files.copy(this.copieq, quiet.toPath(), new java.nio.file.CopyOption[0]);
/*     */         
/* 105 */         Files.copy(this.copiejson, json.toPath(), new java.nio.file.CopyOption[0]);
/*     */         
/* 107 */         JOptionPane.showMessageDialog(this, "Successfully installed", "Installer", 1);
/*     */         
/* 109 */         System.out.println("KOPIERT");
/*     */       }
/* 111 */       catch (Exception e2) {
/*     */         
/* 113 */         JOptionPane.showMessageDialog(this, "Something went wrong, please try again", "Installer", 0);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\speed\Desktop\Installer.jar!\me\Eagler\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */